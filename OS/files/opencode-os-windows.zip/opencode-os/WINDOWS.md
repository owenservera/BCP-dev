# OpenCode OS on Windows 10/11

## Just want the app?

Grab the installer from **GitHub → Actions → "Windows Installer"** (or a Release for a `v*` tag):
`OpenCode OS_0.1.0_x64-setup.exe` (per-user NSIS, no admin needed) or the `.msi`.
On first launch the setup wizard installs the OpenCode CLI and links your free
[Zen key](https://opencode.ai/auth).

## Build it yourself (PowerShell)

1. **Node.js 22+** — `winget install OpenJS.NodeJS.LTS`
2. **Rust** — `winget install Rustlang.Rustup`, then `rustup default stable-msvc`
3. **MSVC Build Tools** — `winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"`
4. **WebView2** — already present on Windows 10 (recent) and 11; otherwise https://developer.microsoft.com/microsoft-edge/webview2/

Open a **new** PowerShell after installing so PATH is refreshed, then:

```powershell
npm ci
npm run tauri:dev      # native window, hot reload of ui/
npm run tauri:build    # installers -> src-tauri\target\release\bundle\{nsis,msi}\
npm start              # browser mode at http://127.0.0.1:8787 (no Rust needed)
npm test               # unit + bridge tests
npm run test:rust      # opencode-core tests
```

## OpenCode CLI

The wizard runs `irm https://opencode.ai/install.ps1 | iex` for you. To do it by hand:
run that line in PowerShell, or `npm i -g opencode-ai` (creates an `opencode.cmd` shim —
the desktop app handles that; browser mode `npm start` needs a native `opencode.exe`,
or set `OPENCODE_BIN` to it).

Check your key: 

```powershell
$env:OPENCODE_API_KEY = "sk-..."
npm run zen:check
```

## Where things live

| What | Windows path |
|------|--------------|
| Settings + API key | `%APPDATA%\opencode-os\settings.json` |
| Default workspace | `%USERPROFILE%\OpenCodeWorkspace` |
| Trash | `<workspace>\.Trash` |

## What changed vs the Linux setup

- Sandbox check now canonicalises the workspace (Windows returns `\\?\C:\…` paths, which broke the
  `starts_with` test — every file operation would have been rejected).
- CLI is launched without flashing a console window; `opencode.cmd` shims are found; PATH is
  reloaded after the installer runs, so no app restart is needed.
- `zen-check.sh` → cross-platform `scripts/zen-check.mjs`; `gen:icons` points at the real script.
- Tests no longer depend on a shebang + `:`-separated PATH (`OPENCODE_BIN` / `OPENCODE_BIN_PREFIX`).
- `npm test` lists files explicitly (`node --test tests` fails on Node 22, and cmd.exe doesn't expand globs).
- The Rust symlink test is `#[cfg(unix)]`; the settings test no longer writes to your real `%APPDATA%`.
- `npm run e2e` / `gates:verify` e2e layer needs POSIX shell quoting: run in WSL or CI
  (skipped on native Windows unless `FORCE_E2E=1`).
