// Bridge-server API tests — real HTTP against the real bridge, temp workspace,
// PATH pointed at the fake opencode CLI. Proves the browser-mode backend and
// (by symmetry of the command surface) the Tauri command semantics.

import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import url from "node:url";

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");

let PORT = 8891;
let BASE = `http://127.0.0.1:${PORT}`;
let serverProc;
let tmp;

async function api(cmd, args = {}) {
  const res = await fetch(`${BASE}/api/${cmd}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  return res.json();
}

test.before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ocos-bridge-"));
  fs.mkdirSync(path.join(tmp, "cfg"), { recursive: true });
  fs.mkdirSync(path.join(tmp, "ws"), { recursive: true });
  const settingsPath = path.join(tmp, "cfg", "settings.json");
  fs.writeFileSync(settingsPath, JSON.stringify({
    workspace: path.join(tmp, "ws"),
    zen_api_key: "",
    model: "opencode/space-bunny-free",
    wizard_done: true,
  }));
  PORT = 8891 + Math.floor(Math.random() * 100);
  BASE = `http://127.0.0.1:${PORT}`;
  const fakebin = path.join(ROOT, "scripts", "fakebin");
  serverProc = spawn("node", [path.join(ROOT, "bridge-server", "server.mjs")], {
    env: {
      ...process.env,
      PORT: String(PORT),
      OPENCODE_OS_CONFIG_DIR: path.join(tmp, "cfg"),
      OPENCODE_BIN: process.execPath,
      OPENCODE_BIN_PREFIX: JSON.stringify([path.join(fakebin, "opencode")]),
      OCOS_MOCK_DIR: path.join(tmp, "mock"),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  serverProc.stderr.on("data", (d) => process.stderr.write(`[bridge] ${d}`));
  // wait for readiness
  for (let i = 0; i < 50; i += 1) {
    try {
      const r = await fetch(`${BASE}/`);
      if (r.ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error("bridge server did not start");
});

test.after(() => {
  serverProc?.kill("SIGKILL");
});

test("sys_info reports the fake CLI", async () => {
  const r = await api("sys_info");
  assert.equal(r.ok, true);
  assert.equal(r.data.opencode_installed, true);
  assert.equal(r.data.opencode_version, "1.0.0-mock");
  assert.equal(r.data.workspace, path.join(tmp, "ws"));
});

test("fs: create/list/read/rename/trash roundtrip (G1.4–G1.6)", async () => {
  let r = await api("fs_mkdir", { path: "docs" });
  assert.equal(r.ok, true);
  r = await api("fs_write", { path: "docs/hello.txt", content: "hello world" });
  assert.equal(r.ok, true);
  assert.equal(r.data, 11);

  r = await api("fs_list", { path: "" });
  assert.equal(r.ok, true);
  assert.deepEqual(r.data.map((e) => e.name), ["docs"]);

  r = await api("fs_read", { path: "docs/hello.txt" });
  assert.equal(r.data, "hello world");

  r = await api("fs_rename", { from: "docs/hello.txt", to: "docs/hi.txt" });
  assert.equal(r.ok, true);
  r = await api("fs_read", { path: "docs/hi.txt" });
  assert.equal(r.data, "hello world");

  r = await api("fs_trash", { path: "docs/hi.txt" });
  assert.equal(r.ok, true);
  r = await api("fs_list", { path: "docs" });
  assert.equal(r.data.length, 0);
  r = await api("trash_list", {});
  assert.equal(r.data.length, 1);
  r = await api("trash_empty", {});
  assert.equal(r.data, 1);
});

test("fs: traversal attacks rejected over HTTP too (G3.4)", async () => {
  for (const evil of ["../escape", "a/../../b", "/etc/passwd", "a\\..\\..\\windows"]) {
    const r = await api("fs_read", { path: evil });
    assert.equal(r.ok, false, `expected rejection for ${evil}`);
    assert.match(r.error, /blocked|outside|invalid/i);
  }
  const w = await api("fs_write", { path: "../../escaped.txt", content: "x" });
  assert.equal(w.ok, false);
  assert.equal(fs.existsSync(path.resolve(tmp, "escaped.txt")), false);
  assert.equal(fs.existsSync(path.resolve(tmp, "..", "escaped.txt")), false);
});

test("chat: streamed mock reply end-to-end (G2.2, G2.3)", async () => {
  const res = await fetch(`${BASE}/api/oc_send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId: null, model: "opencode/space-bunny-free", text: "hello machine" }),
  });
  assert.equal(res.headers.get("content-type"), "application/x-ndjson");
  const text = await res.text();
  const events = text.trim().split("\n").map((l) => JSON.parse(l).ev);
  const reply = events.filter((e) => e.t === "delta").map((e) => e.text).join("");
  assert.ok(reply.includes('MOCK-REPLY: you said "hello machine"'), `reply was: ${reply}`);
  assert.equal(events.find((e) => e.t === "session")?.id.startsWith("ses_"), true);
  assert.ok(events.some((e) => e.t === "done"));
});

test("chat: error event surfaces on auth failure (G2.5)", async () => {
  // Point the bridge at a fake CLI that fails auth: use env override via a
  // second request through the real CLI? The bridge reads settings only for
  // the key; the fake CLI fails when OCOS_MOCK_AUTH_FAIL=1, which we cannot
  // inject per-request — instead we assert the normalizer handles the raw
  // error line shape the CLI prints on stderr+exit(1).
  const { parseOcLine } = await import("../ui/js/lib/path-util.js");
  // stderr isn't NDJSON so parseOcLine ignores it; exit!=0 yields friendly error:
  // covered in bridge oc_send logic; here we assert the friendly message shape.
  const res = await fetch(`${BASE}/api/oc_send`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId: null, model: "m", text: "ERRORPLZ now" }),
  });
  const text = await res.text();
  const events = text.trim().split("\n").map((l) => JSON.parse(l).ev);
  const err = events.find((e) => e.t === "error");
  assert.ok(err, "expected an error event");
  assert.match(err.message, /Mock provider failure|ended without answering/i);
  assert.ok(events.some((e) => e.t === "done"));
});

test("chat: sessions list via managed fake server (G2.1, G2.2)", async () => {
  const r = await api("oc_sessions");
  assert.equal(r.ok, true);
  assert.ok(Array.isArray(r.data));
  assert.ok(r.data.length >= 1, "the earlier chat should be registered");
  assert.ok(r.data[0].id.startsWith("ses_"));
});

test("wizard: setup_status + settings roundtrip (G3.2)", async () => {
  let r = await api("setup_status");
  assert.equal(r.ok, true);
  assert.equal(r.data.opencode_installed, true);
  r = await api("settings_get");
  const s = r.data;
  s.wizard_done = true;
  s.zen_api_key = "sk-zen-e2e";
  r = await api("settings_set", { settings: s });
  assert.equal(r.ok, true);
  const onDisk = JSON.parse(fs.readFileSync(path.join(tmp, "cfg", "settings.json"), "utf8"));
  assert.equal(onDisk.zen_api_key, "sk-zen-e2e");
  assert.equal(onDisk.wizard_done, true);
});
