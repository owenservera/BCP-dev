#!/usr/bin/env node
// Cross-platform live check (Windows / macOS / Linux): verify a Zen API key can
// round-trip through the installed OpenCode CLI.
//
// Usage:
//   PowerShell:  $env:OPENCODE_API_KEY="sk-..."; npm run zen:check
//   cmd.exe:     set OPENCODE_API_KEY=sk-... && npm run zen:check
//   bash:        OPENCODE_API_KEY=sk-... npm run zen:check
// Optional model: npm run zen:check -- opencode/nemotron-3-ultra-free
import { spawnSync } from "node:child_process";

const model = process.argv[2] || "opencode/space-bunny-free";
if (!process.env.OPENCODE_API_KEY) {
  console.error("OPENCODE_API_KEY is not set. Get a free key at https://opencode.ai/auth");
  process.exit(2);
}
console.log(`Model: ${model}`);
console.log("Asking the model to identify itself...");

// On Windows an npm-installed CLI is opencode.cmd; try both names (args are fixed, no user text).
const names = process.platform === "win32" ? ["opencode", "opencode.cmd"] : ["opencode"];
let res;
for (const name of names) {
  res = spawnSync(name, ["run", "-m", model, "Reply with exactly: ZEN_OK"], {
    encoding: "utf8",
    timeout: 90_000,
    shell: name.endsWith(".cmd"),
  });
  if (!res.error) break;
}
if (res.error) {
  console.error(`Could not run the opencode CLI: ${res.error.message}`);
  process.exit(127);
}
const out = `${res.stdout || ""}${res.stderr || ""}`.trim().split(/\r?\n/).slice(-5).join("\n");
console.log(out);
console.log("If the output above contains ZEN_OK, your zen key works.");
process.exit(out.includes("ZEN_OK") ? 0 : 1);
