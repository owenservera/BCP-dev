// Notepad — open, edit, save (Ctrl+S), Save As. Persists to the real fs.

import { h, clear, S, toast } from "../lib/dom.js";
import { bridge } from "../bridge.js";
import { dirname, basename } from "../lib/path-util.js";

export function createNotepad({ path = null } = {}) {
  const rootEl = h("div", { class: "notepad" });
  let currentPath = path;
  let dirty = false;
  let titleCb = null; // set by main.js to update window title

  const ta = h("textarea", { spellcheck: "false", placeholder: "Start typing…" });
  const statusPath = h("span", {}, currentPath ?? "unsaved");
  const statusLen = h("span", {}, "0 chars");

  const fileMenu = h("div", { class: "np-dropdown hidden" },
    item("Save", save),
    item("Save As…", saveAs),
    "-",
    item("Close", () => rootEl.closest(".win") && rootEl.closest(".win").querySelector(".win-ctl.close").click()),
  );
  const fileBtn = h("button", { class: "np-menu-btn" }, "File", fileMenu);
  fileBtn.addEventListener("click", (ev) => {
    ev.stopPropagation();
    fileMenu.classList.toggle("hidden");
    fileBtn.classList.toggle("open", !fileMenu.classList.contains("hidden"));
  });
  window.addEventListener("pointerdown", (ev) => {
    if (!ev.target.closest(".np-menu-btn")) {
      fileMenu.classList.add("hidden");
      fileBtn.classList.remove("open");
    }
  });

  const menu = h("div", { class: "np-menu" }, fileBtn);
  const statusbar = h("div", { class: "np-statusbar" }, statusPath, statusLen);
  rootEl.append(menu, ta, statusbar);

  function item(label, action, hint) {
    return h("div", { class: "ctx-item", onclick: () => { fileMenu.classList.add("hidden"); action(); } },
      h("span", {}, label), hint ? h("span", { class: "ctx-hint" }, hint) : null);
  }

  ta.addEventListener("input", () => {
    dirty = true;
    statusLen.textContent = `${ta.value.length} chars`;
    emitTitle();
  });
  ta.addEventListener("keydown", (ev) => {
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "s") {
      ev.preventDefault();
      save();
    }
  });

  function emitTitle() {
    titleCb && titleCb(`${dirty ? "*" : ""}${currentPath ?? "Untitled"} — Notepad`);
  }

  async function load() {
    if (!currentPath) return;
    try {
      const content = await bridge.invoke("fs_read", { path: currentPath });
      ta.value = content;
      dirty = false;
      statusLen.textContent = `${content.length} chars`;
      statusPath.textContent = currentPath;
      emitTitle();
    } catch (e) {
      toast(String(e.message || e).replace(/^.*error:\s*/, ""));
    }
  }

  async function save() {
    if (!currentPath) return saveAs();
    try {
      await bridge.invoke("fs_write", { path: currentPath, content: ta.value });
      dirty = false;
      emitTitle();
      toast(`Saved ${basename(currentPath)}`);
      document.dispatchEvent(new CustomEvent("os:fs-changed", { detail: { path: dirname(currentPath) } }));
    } catch (e) {
      toast(String(e.message || e).replace(/^.*error:\s*/, ""));
    }
  }

  async function saveAs() {
    const suggested = currentPath ?? "Untitled.txt";
    const name = window.prompt("Save as (name or folder/name):", suggested);
    if (!name) return;
    const clean = String(name).trim().replace(/^\/+|\/+$/g, "");
    if (!clean) return;
    try {
      await bridge.invoke("fs_write", { path: clean, content: ta.value });
      currentPath = clean;
      dirty = false;
      statusPath.textContent = clean;
      emitTitle();
      toast(`Saved ${basename(clean)}`);
      document.dispatchEvent(new CustomEvent("os:fs-changed", { detail: { path: dirname(clean) } }));
    } catch (e) {
      toast(String(e.message || e).replace(/^.*error:\s*/, ""));
    }
  }

  if (path) load();
  else emitTitle();

  return { el: rootEl, setTitleListener(cb) { titleCb = cb; emitTitle(); }, save };
}
