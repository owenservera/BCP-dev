// Settings / About — honest system info, setup links, re-run wizard.

import { h, S, toast } from "../lib/dom.js";
import { bridge } from "../bridge.js";

export function createSettings() {
  const rootEl = h("div", { class: "settings-app" });
  const pill = (ok, okText, warnText) =>
    h("span", { class: `status-pill ${ok ? "ok" : "warn"}` }, ok ? okText : warnText);

  (async () => {
    let info = {};
    let settings = {};
    try {
      info = await bridge.invoke("sys_info", {});
      settings = await bridge.invoke("settings_get", {});
    } catch (e) {
      rootEl.append(h("p", {}, `Could not load settings: ${e.message || e}`));
      return;
    }
    const oc = info.opencode_installed;
    rootEl.append(
      h("h2", {}, "Settings"),
      h("p", { class: "hint" }, "OpenCode OS — your desktop for the OpenCode CLI."),
      h("div", { class: "sec" },
        h("h3", {}, "Machine"),
        row("OpenCode OS version", `<code>${info.app_version ?? "?"}</code>`),
        row("OpenCode CLI", pill(oc, `installed ${info.opencode_version ?? ""}`, "not installed")),
        row("Platform", info.os ?? "?"),
        row("Workspace", `<code>${info.workspace ?? "?"}</code>`),
      ),
      h("div", { class: "sec" },
        h("h3", {}, "AI service (OpenCode Zen)"),
        row("Zen API key", pill(settings.zen_api_key ? true : false, "configured", "not set")),
        row("Default model", `<code>${settings.model ?? "?"}</code>`),
        h("p", { class: "hint" },
          "Free models are provided by OpenCode Zen. Get a key at ",
          h("a", { href: "https://opencode.ai/auth", target: "_blank", rel: "noreferrer" }, "opencode.ai/auth"),
          " — it takes about a minute.",
        ),
      ),
      h("div", { class: "sec" },
        h("h3", {}, "Setup"),
        h("div", { style: "display:flex;gap:10px;margin-top:6px;" },
          h("button", {
            class: "btn primary",
            onclick: () => document.dispatchEvent(new CustomEvent("os:open-setup")),
          }, "Re-run first-run setup"),
        ),
      ),
    );
  })();

  function row(label, valueHtml) {
    const val = h("div", { class: "val" });
    if (typeof valueHtml === "string") val.innerHTML = valueHtml;
    else val.append(valueHtml);
    return h("div", { class: "set-row" }, h("div", {}, label), val);
  }

  return rootEl;
}

export { toast };
